def Add_Next_Date(df):
    df['Next_infraction_Date']=df.sort_values(by=['Infraction Date'],ascending=True).groupby('Driver ID')['Infraction Date'].shift(-1)
    return df

def get_output_schema():       
      return pd.DataFrame({
          'Driver ID':prep_string(),
          'Infraction Date':prep_date(),
          'Next_infraction_Date' : prep_date(),
          'Infraction Type':prep_string(), 
          'Traffic School':prep_string(),
          'Fine Amount':prep_int()     
})
    